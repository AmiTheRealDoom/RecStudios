(function () {
  var POLL_MS = 10000;
  var last = { players: null, loaded: false };
  var inFlight = false;

  function apply() {
    var state = !last.loaded ? "loading" : last.players == null ? "unavailable" : "online";
    var text = last.players == null ? "–" : Number(last.players).toLocaleString();

    document.querySelectorAll("[data-revium-players]").forEach(function (box) {
      box.dataset.state = state;
    });
    document.querySelectorAll("[data-revium-players-count]").forEach(function (node) {
      if (node.textContent !== text) node.textContent = text;
    });
  }

  function load() {
    if (inFlight || document.hidden) return;
    inFlight = true;
    fetch("/api/status?only=players", { cache: "no-store" })
      .then(function (r) {
        if (!r.ok) throw new Error("bad status");
        return r.json();
      })
      .then(function (data) {
        last = { players: typeof data.players === "number" ? data.players : null, loaded: true };
      })
      .catch(function () {
        last = { players: null, loaded: true };
      })
      .then(function () {
        inFlight = false;
        apply();
      });
  }

  function start() {
    apply();
    load();
    setInterval(load, POLL_MS);
  }

  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) load();
  });

  window.ReviumPlayers = { apply: apply, refresh: load };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
