const TOPBAR_STYLE_ID = "Recquiem-topbar-styles";
const UPDATE_SEEN_KEY = "RecquiemLastSeenUpdate";
const UPDATE_SEEN_MAP_KEY = "RecquiemLastSeenUpdates";
const UPDATE_CATEGORIES = [
  { id: "website", page: "WebsitePatchNotes.html" },
  { id: "game", page: "GamePatchNotes.html" }
];
const UPDATE_HUB_PAGE = "Updates.html";

document.documentElement.setAttribute("data-nav", "top");
document.addEventListener("DOMContentLoaded", loadTopbar);

(function loadDownloadTransition() {
  const id = "Recquiem-download-transition-script";

  if (window.RQDownloadTransition || document.getElementById(id)) {
    return;
  }

  const script = document.createElement("script");
  script.id = id;
  script.src = new URL("Script/download-transition.js", document.baseURI).href;
  script.defer = true;
  document.head.appendChild(script);
})();

function loadTopbarStyles() {
  if (document.getElementById(TOPBAR_STYLE_ID)) {
    return;
  }

  const stylesheet = document.createElement("link");
  stylesheet.id = TOPBAR_STYLE_ID;
  stylesheet.rel = "stylesheet";
  stylesheet.href = "Style/topbar.css";
  document.head.appendChild(stylesheet);
}

async function loadTopbar() {
  const container = document.getElementById("topbar");
  if (!container) return;
  loadTopbarStyles();

  try {
    const response = await fetch(new URL("Topbar.html", document.baseURI).href, {
      cache: "no-cache"
    });
    if (!response.ok) throw new Error("Topbar request failed: " + response.status);

    const template = document.createElement("template");
    template.innerHTML = (await response.text()).trim();
    container.replaceChildren(...template.content.cloneNode(true).childNodes);

    const nav = container.querySelector("#site-topbar");
    const toggle = container.querySelector("#mobile-topbar-toggle");
    if (!nav || !toggle) throw new Error("Nav controls not found.");

    setActiveTopbarLink(container);
    initializeUpdatesPing(container);
    initializeNavMenus(nav, toggle);
    initializeTopbarAutoHide(nav);
    initializeSettingsPanel();
    initializeSiteSearch();
    if (window.RQI18n) window.RQI18n.refresh();
  } catch (error) {
    console.error("Failed to load navigation:", error);
  }
}

function initializeSiteSearch() {
  if (document.getElementById("Recquiem-search-script")) return;
  const existing = document.querySelector('script[src$="Script/search.js"]');
  if (existing) return;
  const script = document.createElement("script");
  script.id = "Recquiem-search-script";
  script.src = new URL("Script/search.js", document.baseURI).href;
  script.defer = false;
  document.body.appendChild(script);
}

function initializeNavMenus(nav, toggle) {
  const more = nav.querySelector(".nav-more");
  const moreBtn = nav.querySelector(".nav-more-btn");

  const closeMobile = () => {
    nav.classList.remove("mobile-topbar-open");
    toggle.setAttribute("aria-expanded", "false");
  };
  const closeMore = () => {
    more?.classList.remove("open");
    moreBtn?.setAttribute("aria-expanded", "false");
  };

  toggle.addEventListener("click", event => {
    event.stopPropagation();
    const open = !nav.classList.contains("mobile-topbar-open");
    nav.classList.toggle("mobile-topbar-open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });

  moreBtn?.addEventListener("click", event => {
    event.stopPropagation();
    const open = !more.classList.contains("open");
    more.classList.toggle("open", open);
    moreBtn.setAttribute("aria-expanded", String(open));
  });

  const dropdowns = Array.from(nav.querySelectorAll(".nav-dropdown"));
  const closeDropdowns = except => {
    dropdowns.forEach(dd => {
      if (dd === except) return;
      dd.classList.remove("open");
      dd.querySelector(".nav-dropdown-btn")?.setAttribute("aria-expanded", "false");
    });
  };
  dropdowns.forEach(dd => {
    const btn = dd.querySelector(".nav-dropdown-btn");
    btn?.addEventListener("click", event => {
      event.stopPropagation();
      const open = !dd.classList.contains("open");
      closeDropdowns(dd);
      dd.classList.toggle("open", open);
      btn.setAttribute("aria-expanded", String(open));
    });
    if (dd.querySelector(".nav-submenu a.active")) dd.classList.add("has-active");
  });

  document.addEventListener("click", event => {
    if (!nav.contains(event.target)) {
      closeMore();
      closeMobile();
      closeDropdowns();
    }
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      closeDropdowns();
      closeMore();
      closeMobile();
    }
  });
}

function initializeTopbarAutoHide(nav) {
  const query = window.matchMedia("(max-width: 1024px), (hover: none) and (pointer: coarse)");
  let lastY = window.scrollY;
  let ticking = false;

  const isLocked = () =>
    nav.classList.contains("mobile-topbar-open") ||
    Boolean(nav.querySelector(".nav-dropdown.open")) ||
    Boolean(nav.querySelector(".search-panel.active")) ||
    nav.contains(document.activeElement) && document.activeElement.tagName === "INPUT";

  const update = () => {
    ticking = false;
    const y = Math.max(0, window.scrollY);
    const delta = y - lastY;

    if (!query.matches || y < 80 || isLocked()) {
      nav.classList.remove("topbar-hidden");
    } else if (delta > 8) {
      nav.classList.add("topbar-hidden");
    } else if (delta < -8) {
      nav.classList.remove("topbar-hidden");
    }

    if (Math.abs(delta) > 8 || y < 80) lastY = y;
  };

  window.addEventListener(
    "scroll",
    () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(update);
    },
    { passive: true }
  );

  const reset = () => {
    nav.classList.remove("topbar-hidden");
    lastY = window.scrollY;
  };

  window.addEventListener("resize", reset);
  window.addEventListener("orientationchange", reset);
}

function normalizePageName(value) {
  const path = String(value || "")
    .split("?")[0]
    .split("#")[0]
    .split("/")
    .pop()
    .toLowerCase();

  return path.replace(/\.html$/, "");
}

function getCurrentPageName() {
  return normalizePageName(window.location.pathname) || "home";
}

function setActiveTopbarLink(topbarContainer) {
  const currentPage = getCurrentPageName();

  topbarContainer.querySelectorAll(".mobile-bottom-bar .mbb-item").forEach(item => {
    const active = item.dataset.page === currentPage;
    item.classList.toggle("active", active);
    if (active) item.setAttribute("aria-current", "page");
  });

  topbarContainer.querySelectorAll(".nav-links a").forEach(link => {
    const linkPage = normalizePageName(new URL(link.href, window.location.href).pathname) || "home";

    if (linkPage === currentPage) {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    }
  });
}

function readSeenUpdates() {
  try {
    const parsed = JSON.parse(localStorage.getItem(UPDATE_SEEN_MAP_KEY) || "{}");

    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch (error) {
    return {};
  }
}

function writeSeenUpdates(seen) {
  try {
    localStorage.setItem(UPDATE_SEEN_MAP_KEY, JSON.stringify(seen));
  } catch (error) {
    console.warn("Could not persist seen updates:", error);
  }
}

async function getCategorySignature(page) {
  try {
    const pageUrl = new URL(page, document.baseURI);
    const response = await fetch(pageUrl.href, { cache: "no-cache" });

    if (!response.ok) {
      return "";
    }

    const markup = await response.text();
    const doc = new DOMParser().parseFromString(markup, "text/html");
    const card = doc.querySelector(".patch-note-card");

    if (!card) {
      return "";
    }

    const eyebrow = card.querySelector(".patch-note-eyebrow");
    const title = card.querySelector(".patch-note-title");

    return [eyebrow, title]
      .map(node => (node ? node.textContent.trim() : ""))
      .filter(Boolean)
      .join(" | ");
  } catch (error) {
    console.warn(`Failed to check ${page} for updates:`, error);

    return "";
  }
}

async function getUpdateCategories() {
  const categories = await Promise.all(
    UPDATE_CATEGORIES.map(async category => ({
      ...category,
      signature: await getCategorySignature(category.page)
    }))
  );

  return categories.filter(category => Boolean(category.signature));
}

function migrateLegacySeenUpdates(categories, seen) {
  const legacy = localStorage.getItem(UPDATE_SEEN_KEY);

  if (!legacy) {
    return seen;
  }

  const hasStoredCategory = categories.some(category =>
    Object.prototype.hasOwnProperty.call(seen, category.id)
  );

  if (!hasStoredCategory) {
    categories.forEach(category => {
      if (legacy.includes(`${category.page}:`)) {
        seen[category.id] = category.signature;
      }
    });

    writeSeenUpdates(seen);
  }

  try {
    localStorage.removeItem(UPDATE_SEEN_KEY);
  } catch (error) {
    console.warn("Could not clear the legacy update key:", error);
  }

  return seen;
}

function createUpdatePing(className) {
  const ping = document.createElement("span");

  ping.className = className;
  ping.setAttribute("aria-hidden", "true");

  return ping;
}

function setTopbarUpdatePing(topbarContainer, hasUnread) {
  const hubPage = normalizePageName(UPDATE_HUB_PAGE);
  const updatesLink = Array.from(topbarContainer.querySelectorAll(".nav-links a")).find(
    link => normalizePageName(new URL(link.href, window.location.href).pathname) === hubPage
  );

  if (!updatesLink) {
    return;
  }

  const existing = updatesLink.querySelector(".topbar-update-ping");

  if (!hasUnread) {
    if (existing) {
      existing.remove();
    }

    return;
  }

  if (!existing) {
    updatesLink.appendChild(createUpdatePing("topbar-update-ping"));
  }
}

function decorateUpdateCards(categories, seen) {
  const cards = document.querySelectorAll("a.updates-category-card");

  if (!cards.length) {
    return;
  }

  cards.forEach(card => {
    const cardPage = normalizePageName(new URL(card.href, window.location.href).pathname);
    const category = categories.find(entry => normalizePageName(entry.page) === cardPage);
    const isUnread = Boolean(category) && seen[category.id] !== category.signature;
    const existing = card.querySelector(".updates-category-ping");

    card.classList.toggle("has-update", isUnread);

    if (!isUnread) {
      if (existing) {
        existing.remove();
      }

      return;
    }

    if (!existing) {
      card.appendChild(createUpdatePing("updates-category-ping"));
    }
  });
}

async function initializeUpdatesPing(topbarContainer) {
  const categories = await getUpdateCategories();

  if (!categories.length) {
    return;
  }

  const seen = migrateLegacySeenUpdates(categories, readSeenUpdates());
  const currentPage = getCurrentPageName();
  const currentCategory = categories.find(
    category => normalizePageName(category.page) === currentPage
  );

  if (currentCategory && seen[currentCategory.id] !== currentCategory.signature) {
    seen[currentCategory.id] = currentCategory.signature;
    writeSeenUpdates(seen);
  }

  const hasUnread = categories.some(category => seen[category.id] !== category.signature);

  setTopbarUpdatePing(topbarContainer, hasUnread);
  decorateUpdateCards(categories, seen);
}

function initializeSettingsPanel() {
  const toggles = document.querySelectorAll(".hero-settings-btn");
  const panel = document.getElementById("settings-panel");
  const backdrop = document.getElementById("settings-backdrop");
  const closeButton = document.getElementById("settings-panel-close");

  if (!panel || !backdrop) {
    return;
  }

  const openPanel = () => {
    panel.classList.add("open");
    backdrop.classList.add("open");
    panel.setAttribute("aria-hidden", "false");
    toggles.forEach(toggle => toggle.setAttribute("aria-expanded", "true"));
  };

  const closePanel = () => {
    panel.classList.remove("open");
    backdrop.classList.remove("open");
    panel.setAttribute("aria-hidden", "true");
    toggles.forEach(toggle => toggle.setAttribute("aria-expanded", "false"));
  };

  toggles.forEach(toggle => {
    toggle.setAttribute("aria-controls", "settings-panel");
    toggle.setAttribute("aria-expanded", "false");
    toggle.addEventListener("click", event => {
      event.stopPropagation();

      if (panel.classList.contains("open")) {
        closePanel();
      } else {
        openPanel();
      }
    });
  });

  closeButton?.addEventListener("click", closePanel);
  backdrop.addEventListener("click", closePanel);

  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && panel.classList.contains("open")) {
      closePanel();
    }
  });
}
