const PUSH_PREF_KEY = "RecquiemPushEnabled";

function isPushSupported() {
  return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; i += 1) {
    outputArray[i] = rawData.charCodeAt(i);
  }

  return outputArray;
}

async function fetchPublicKey() {
  const response = await fetch("/api/push-public-key");

  if (!response.ok) {
    throw new Error("Push notifications are not available right now.");
  }

  const data = await response.json();
  return data.publicKey;
}

async function subscribeToPush() {
  if (!isPushSupported()) {
    throw new Error("This browser doesn't support push notifications.");
  }

  const permission = await Notification.requestPermission();

  if (permission !== "granted") {
    throw new Error("Notification permission was not granted.");
  }

  const registration = await navigator.serviceWorker.ready;
  const publicKey = await fetchPublicKey();

  let subscription = await registration.pushManager.getSubscription();

  if (!subscription) {
    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicKey)
    });
  }

  const response = await fetch("/api/push-subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ subscription })
  });

  if (!response.ok) {
    throw new Error("Could not save your subscription.");
  }

  localStorage.setItem(PUSH_PREF_KEY, "true");
  return true;
}

async function unsubscribeFromPush() {
  localStorage.setItem(PUSH_PREF_KEY, "false");

  if (!isPushSupported()) {
    return true;
  }

  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.getSubscription();

  if (!subscription) {
    return true;
  }

  try {
    await fetch("/api/push-unsubscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ endpoint: subscription.endpoint })
    });
  } catch (error) {
    console.warn("Could not notify the server of the unsubscribe:", error);
  }

  await subscription.unsubscribe();
  return true;
}

function getPushPermissionHintMessage() {
  const ua = navigator.userAgent || "";

  if (/OculusBrowser|Quest/i.test(ua)) {
    return "Notifications are blocked. In Oculus Browser, tap the site info icon next to the address bar, turn on Notifications for Recquiem, then try again.";
  }

  if (/iPhone|iPad|iPod/i.test(ua)) {
    return "Notifications are blocked. Open Settings > Notifications > Recquiem on your device and turn them on, then try again.";
  }

  if (/Android/i.test(ua)) {
    return "Notifications are blocked. Open your phone's Settings > Apps > Recquiem > Notifications and turn them on, then try again.";
  }

  return "Notifications are blocked. Enable notifications for Recquiem in your browser's site settings, then try again.";
}

function setPushPermissionHintVisible(visible) {
  const hint = document.getElementById("push-permission-hint");

  if (!hint) {
    return;
  }

  if (visible) {
    hint.textContent = getPushPermissionHintMessage();
    hint.hidden = false;
  } else {
    hint.hidden = true;
  }
}

function setPushToggleState(toggle, status, enabled) {
  toggle.setAttribute("aria-checked", String(enabled));
  toggle.classList.toggle("is-on", enabled);

  const supported = isPushSupported();
  const denied = supported && Notification.permission === "denied";

  if (status) {
    if (!supported) {
      status.textContent = "Not supported on this browser/device.";
    } else if (denied) {
      status.textContent = "Blocked in browser settings.";
    } else {
      status.textContent = enabled ? "On" : "Off";
    }
  }

  setPushPermissionHintVisible(denied);
}

function initializePushToggle() {
  const toggle = document.getElementById("push-notifications-toggle");

  if (!toggle || toggle.dataset.pushBound === "true") {
    return;
  }

  toggle.dataset.pushBound = "true";

  const status = document.getElementById("push-notifications-status");
  const supported = isPushSupported();

  if (!supported) {
    toggle.disabled = true;
    setPushToggleState(toggle, status, false);
    return;
  }

  navigator.serviceWorker.ready
    .then(registration => registration.pushManager.getSubscription())
    .then(subscription => {
      const enabled = Boolean(subscription) && Notification.permission === "granted";
      setPushToggleState(toggle, status, enabled);
    })
    .catch(() => {
      setPushToggleState(toggle, status, localStorage.getItem(PUSH_PREF_KEY) === "true");
    });

  toggle.addEventListener("click", async () => {
    if (toggle.disabled) {
      return;
    }

    const currentlyOn = toggle.classList.contains("is-on");
    toggle.disabled = true;

    try {
      if (currentlyOn) {
        await unsubscribeFromPush();
        setPushToggleState(toggle, status, false);
      } else {
        await subscribeToPush();
        setPushToggleState(toggle, status, true);
      }
    } catch (error) {
      console.warn("Push toggle error:", error);
      setPushToggleState(toggle, status, false);

      if (status && Notification.permission !== "denied") {
        status.textContent = error.message || "Something went wrong.";
      }
    } finally {
      toggle.disabled = false;
    }
  });
}

new MutationObserver(() => {
  if (document.getElementById("push-notifications-toggle")) {
    initializePushToggle();
  }
}).observe(document.documentElement, { childList: true, subtree: true });

document.addEventListener("DOMContentLoaded", initializePushToggle);
