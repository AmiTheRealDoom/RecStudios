const USERS_API_URL = "/api/users";
const USER_PAGE_URL = "User.html";

const usersGrid = document.getElementById("users-grid");
const usersStatus = document.getElementById("users-status");
const userSearch = document.getElementById("user-search");

const profileStatus = document.getElementById("profile-status");
const profileCard = document.getElementById("profile-card");

let allUsers = [];

function getUserValue(user, keys, fallback = "") {
  for (const key of keys) {
    if (
      user[key] !== undefined &&
      user[key] !== null &&
      String(user[key]).trim()
    ) {
      return String(user[key]).trim();
    }
  }

  return fallback;
}

function getUserId(user) {
  return getUserValue(user, ["UserID", "userId", "user_id"]);
}

function getUsername(user) {
  return getUserValue(user, ["username", "Username"], "unknown");
}

function getDisplayName(user) {
  return getUserValue(
    user,
    ["display_name", "displayName", "DisplayName"],
    getUsername(user)
  );
}

function getProfileImage(user) {
  return getUserValue(user, [
    "Profile",
    "profile",
    "profile_image",
    "profileImage",
    "profile_url",
    "profileUrl",
    "avatar",
    "avatar_url",
    "avatarUrl",
    "image"
  ]);
}

function getUserRoles(user) {
  const roles = user.roles || user.Roles;
  return Array.isArray(roles) ? roles : [];
}

function formatNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toLocaleString() : "0";
}

function formatJoinedDate(value) {
  const date = new Date(value);

  if (!value || Number.isNaN(date.getTime())) {
    return "Unknown";
  }

  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}

function getInitials(user) {
  return getDisplayName(user)
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0].toUpperCase())
    .join("") || "?";
}

function createProfileImage(user) {
  const imageUrl = getProfileImage(user);

  if (!imageUrl) {
    const fallback = document.createElement("div");
    fallback.className = "user-avatar";
    fallback.textContent = getInitials(user);
    fallback.setAttribute("aria-hidden", "true");
    return fallback;
  }

  const image = document.createElement("img");
  image.className = "user-avatar user-profile-image";
  image.src = imageUrl;
  image.alt = `${getDisplayName(user)} profile`;
  image.loading = "lazy";

  image.onerror = () => {
    const fallback = document.createElement("div");
    fallback.className = "user-avatar";
    fallback.textContent = getInitials(user);
    fallback.setAttribute("aria-hidden", "true");
    image.replaceWith(fallback);
  };

  return image;
}

function createUserUrl(user) {
  const userId = getUserId(user);

  return `${USER_PAGE_URL}?UserID=${encodeURIComponent(userId)}`;
}

function createUserCard(user) {
  const displayName = getDisplayName(user);
  const username = getUsername(user);
  const level = getUserValue(user, ["level", "Level"], "0");

  const card = document.createElement("a");
  card.className = "user-card";
  card.href = createUserUrl(user);
  card.setAttribute("aria-label", `View ${displayName}'s profile`);

  const content = document.createElement("div");
  content.className = "user-card-content";

  const name = document.createElement("h2");
  name.className = "user-display-name";
  name.textContent = displayName;

  const handle = document.createElement("p");
  handle.className = "user-handle";
  handle.textContent = `@${username}`;

  const levelText = document.createElement("p");
  levelText.className = "user-level";
  levelText.textContent = `Level ${formatNumber(level)}`;

  content.append(name, handle, levelText);
  card.append(createProfileImage(user), content);

  return card;
}

const STAFF_ROLES = ["Developer", "Moderator", "Support", "Editor"];

const USER_CATEGORIES = ["Owner", "Admins", "Staff", "Players"];

function getUserCategory(user) {
  const roles = getUserRoles(user);

  if (roles.includes("Owner")) return "Owner";
  if (roles.includes("Admin")) return "Admins";
  if (roles.some(role => STAFF_ROLES.includes(role))) return "Staff";
  return "Players";
}

function createCategoryHeading(title, count) {
  const heading = document.createElement("h2");
  heading.className = "users-category-title";
  heading.textContent = title;

  const badge = document.createElement("span");
  badge.className = "users-category-count";
  badge.textContent = count;

  heading.appendChild(badge);
  return heading;
}

function renderUsers(users) {
  usersGrid.replaceChildren();

  if (!users.length) {
    const emptyMessage = document.createElement("p");
    emptyMessage.className = "users-empty";
    emptyMessage.textContent = "No users found.";
    usersGrid.appendChild(emptyMessage);
    return;
  }

  USER_CATEGORIES.forEach(category => {
    const members = users.filter(user => getUserCategory(user) === category);
    if (!members.length) return;

    usersGrid.appendChild(createCategoryHeading(category, members.length));
    members.forEach(user => {
      usersGrid.appendChild(createUserCard(user));
    });
  });
}

function filterUsers() {
  const searchTerm = userSearch.value.trim().toLowerCase();

  const filteredUsers = allUsers.filter(user => {
    const username = getUsername(user).toLowerCase();
    const displayName = getDisplayName(user).toLowerCase();

    return (
      username.includes(searchTerm) ||
      displayName.includes(searchTerm)
    );
  });

  usersStatus.textContent = `${filteredUsers.length} user${
    filteredUsers.length === 1 ? "" : "s"
  } found.`;

  renderUsers(filteredUsers);
}

function showUsersError(message) {
  usersStatus.className = "users-status error";
  usersStatus.textContent = message;

  const retryButton = document.createElement("button");
  retryButton.className = "retry-button";
  retryButton.textContent = "Try Again";
  retryButton.addEventListener("click", loadUsers);

  usersStatus.append(document.createElement("br"), retryButton);
}

async function loadUsers() {
  usersGrid.replaceChildren();
  usersStatus.className = "users-status";
  usersStatus.textContent = "Loading users...";

  try {
    const response = await fetch(USERS_API_URL);

    if (!response.ok) {
      throw new Error(`Users request failed with status ${response.status}`);
    }

    const result = await response.json();

    allUsers = Array.isArray(result)
      ? result
      : result.users || result.profiles || [];

    if (!Array.isArray(allUsers)) {
      throw new Error("Invalid users response.");
    }

    filterUsers();
  } catch (error) {
    console.error("Failed to load users:", error);
    showUsersError("Unable to load users from the Recquiem database.");
  }
}

const ROLE_BADGE_CLASSES = {
  Admin: "badge-admin",
  Owner: "badge-owner",
  Developer: "badge-dev",
  Editor: "badge-editor",
  Moderator: "badge-mod",
  "Music Artist": "badge-music-artist",
  Tester: "badge-tester",
  Support: "badge-support",
  Contributor: "badge-contributor",
  "RQ+": "badge-rqplus",
  OG: "badge-og",
  "Community Helper": "badge-community-helper"
};

async function applyCustomBadgeStyles(container) {
  if (!window.RQBadges) return;

  const saved = await window.RQBadges.fetchSettings();

  container.querySelectorAll(".user-badge").forEach(badge => {
    const setting = saved[badge.dataset.role];
    if (setting) window.RQBadges.applyStyle(badge, setting);
  });
}

function getUserParameters() {
  const params = new URLSearchParams(window.location.search);
  return { userId: params.get("UserID") };
}

function showProfileError(message) {
  document.title = "Recquiem - User";
  profileStatus.className = "profile-status error";
  profileStatus.textContent = message;
  profileCard.hidden = true;
}

function showProfile(user) {
  const displayName = getDisplayName(user);
  const username = getUsername(user);
  const level = getUserValue(user, ["level", "Level"], "0");
  const xp = getUserValue(user, ["xp", "XP"], "0");
  const joined = getUserValue(user, ["joined", "Joined", "created_at"], "");
  const bio = getUserValue(user, ["bio", "Bio"], "No bio available.");

  document.title = `Recquiem - ${displayName}`;

  const bannerUrl = user.thumbnail || "";
  const bannerEl = document.querySelector(".profile-banner");
  if (bannerEl) {
    if (bannerUrl) {
      bannerEl.style.backgroundImage = `url('${bannerUrl}')`;
      bannerEl.style.backgroundSize = "cover";
      bannerEl.style.backgroundPosition = "center";
    } else {
      bannerEl.style.backgroundImage = "";
    }
  }

  const imageUrl = getProfileImage(user);
  const image = document.getElementById("profile-image");
  const initials = document.getElementById("profile-initials");

  if (imageUrl) {
    image.src = imageUrl;
    image.alt = `${displayName} profile`;
    image.hidden = false;
    initials.hidden = true;

    image.onerror = () => {
      image.hidden = true;
      initials.hidden = false;
    };
  } else {
    image.hidden = true;
    initials.hidden = false;
  }

  initials.textContent = getInitials(user);

  document.getElementById("profile-name").textContent = displayName;
  document.getElementById("profile-username").textContent = `@${username}`;
  document.getElementById("profile-bio").textContent = bio;
  document.getElementById("profile-level").textContent = formatNumber(level);
  document.getElementById("profile-xp").textContent = formatNumber(xp);
  document.getElementById("profile-joined").textContent =
    formatJoinedDate(joined);

  const badgesContainer = document.getElementById("profile-badges");
  badgesContainer.replaceChildren();

  getUserRoles(user).forEach(role => {
    const badgeClass = ROLE_BADGE_CLASSES[role];
    if (!badgeClass) return;

    const badge = document.createElement("span");
    badge.className = `user-badge ${badgeClass}`;
    badge.textContent = role;
    badge.dataset.role = role;
    badgesContainer.appendChild(badge);
  });

  applyCustomBadgeStyles(badgesContainer);

  profileStatus.hidden = true;
  profileCard.hidden = false;

  if (window.initUserReactions) {
    window.initUserReactions(getUserId(user));
  }
}

async function loadUserProfile() {
  const { userId } = getUserParameters();

  if (!userId) {
    showProfileError("This profile URL is missing its user information.");
    return;
  }

  try {
    const response = await fetch(USERS_API_URL);

    if (!response.ok) {
      throw new Error(`Users request failed with status ${response.status}`);
    }

    const result = await response.json();
    const users = Array.isArray(result)
      ? result
      : result.users || result.profiles || [];

    const user = users.find(candidate => getUserId(candidate) === userId);

    if (!user) {
      showProfileError("User not found.");
      return;
    }

    showProfile(user);
  } catch (error) {
    console.error("Failed to load profile:", error);
    showProfileError("Unable to load this profile.");
  }
}

if (usersGrid) {
  userSearch.addEventListener("input", filterUsers);
  loadUsers();
}

if (profileStatus && profileCard) {
  loadUserProfile();
}
