(function () {
  var COOKIE_NAME = "googtrans";

  var LANGUAGES = [
    { code: "en", label: "English", flag: "🇬🇧" },
    { code: "fr", label: "Français", flag: "🇫🇷" },
    { code: "es", label: "Español", flag: "🇪🇸" },
    { code: "ru", label: "Русский", flag: "🇷🇺" },
    { code: "de", label: "Deutsch", flag: "🇩🇪" },
    { code: "ar", label: "العربية", flag: "🇸🇦" },
    { code: "zh-CN", label: "中文", flag: "🇨🇳" },
    { code: "it", label: "Italiano", flag: "🇮🇹" },
    { code: "ro", label: "Română", flag: "🇷🇴" },
    { code: "hu", label: "Magyar", flag: "🇭🇺" }
  ];

  function getCookie(name) {
    var match = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : "";
  }

  function setCookie(name, value) {
    var d = new Date();
    d.setTime(d.getTime() + 365 * 24 * 60 * 60 * 1000);
    var expires = "expires=" + d.toUTCString();

    document.cookie = name + "=" + value + "; " + expires + "; path=/";

    var hostParts = window.location.hostname.split(".");
    if (hostParts.length > 2) {
      var apexDomain = "." + hostParts.slice(-2).join(".");
      document.cookie = name + "=" + value + "; " + expires + "; path=/; domain=" + apexDomain;
    }
  }

  function detectSupportedLanguage() {
    var supported = LANGUAGES.map(function (lang) {
      return lang.code;
    });

    var browserLangs = (navigator.languages &&
      navigator.languages.length &&
      navigator.languages) || [navigator.language || navigator.userLanguage || "en"];

    for (var i = 0; i < browserLangs.length; i++) {
      var raw = (browserLangs[i] || "").toLowerCase();
      if (raw.indexOf("zh") === 0) return "zh-CN";

      var primary = raw.split("-")[0];
      for (var j = 0; j < supported.length; j++) {
        var code = supported[j].toLowerCase();
        if (code === raw || code === primary) return supported[j];
      }
    }

    return null;
  }

  function currentLang() {
    var cookieVal = getCookie(COOKIE_NAME);
    if (cookieVal) {
      var pieces = cookieVal.split("/");
      if (pieces.length >= 3 && pieces[2]) return pieces[2];
    }
    return "en";
  }

  function setLanguage(langCode) {
    setCookie(COOKIE_NAME, langCode === "en" ? "/en/en" : "/en/" + langCode);
    window.location.reload();
  }

  function populateLanguageSelect(select) {
    if (!select || select.options.length) return;

    LANGUAGES.forEach(function (lang) {
      var option = document.createElement("option");
      option.value = lang.code;
      option.textContent = lang.flag + " " + lang.label;
      select.appendChild(option);
    });

    select.value = currentLang();

    select.addEventListener("change", function () {
      setLanguage(select.value);
    });
  }

  if (!getCookie(COOKIE_NAME)) {
    var detected = detectSupportedLanguage();
    if (detected && detected !== "en") {
      setLanguage(detected);
      return;
    }
  }

  window.googleTranslateElementInit = function () {
    new google.translate.TranslateElement(
      {
        pageLanguage: "en",
        includedLanguages: "en,fr,es,ru,de,ar,zh-CN,it,ro,hu",
        autoDisplay: false
      },
      "google_translate_element"
    );
  };

  window.RQI18n = {
    refresh: function () {
      populateLanguageSelect(document.getElementById("topbar-lang-select"));
    }
  };

  document.addEventListener("DOMContentLoaded", function () {
    document.documentElement.setAttribute("lang", currentLang());
    populateLanguageSelect(document.getElementById("topbar-lang-select"));
  });
})();
