(function () {
  var COUNT = 5;
  var mount = document.getElementById("home-rooms-list");
  if (!mount) return;

  var FALLBACK = "Icons/Compete.png";

  function pick(game, keys, fallback) {
    for (var i = 0; i < keys.length; i++) {
      var v = game[keys[i]];
      if (v !== undefined && v !== null && String(v).trim()) return String(v).trim();
    }
    return fallback;
  }

  function el(tag, className, text) {
    var n = document.createElement(tag);
    if (className) n.className = className;
    if (text != null) n.textContent = text;
    return n;
  }

  function roomUrl(game) {
    var by = pick(game, ["ByID", "by_id", "ById", "byId"], pick(game, ["By"], "unknown"));
    var id = pick(
      game,
      ["RoomID", "room_id", "RoomId", "roomId"],
      pick(game, ["RoomName", "room_name"], "unknown")
    );
    return "Room.html?" + new URLSearchParams({ ByID: by, RoomID: id }).toString();
  }

  function card(game) {
    var name = pick(game, ["RoomName", "room_name"], "Unnamed Room");
    var by = pick(game, ["By", "by", "creator"], "Unknown");

    var a = el("a", "home-room-card");
    a.href = roomUrl(game);

    var img = el("img");
    img.loading = "lazy";
    img.alt = name + " thumbnail";
    img.src = pick(
      game,
      [
        "Thumbnail",
        "thumbnail",
        "thumbnail_url",
        "thumbnailUrl",
        "RoomThumbnail",
        "room_thumbnail"
      ],
      FALLBACK
    );
    img.onerror = function () {
      if (!img.src.endsWith(FALLBACK)) img.src = FALLBACK;
    };

    var text = el("div", "home-room-text");
    text.append(el("span", "home-room-name", "^" + name), el("span", "home-room-by", "@" + by));
    a.append(img, text);
    return a;
  }

  function empty(msg) {
    mount.replaceChildren(el("p", "home-rooms-empty", msg));
  }

  fetch("/api/rooms")
    .then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.json();
    })
    .then(function (result) {
      var games = Array.isArray(result) ? result : result.rooms || result.games;
      if (!Array.isArray(games) || !games.length) return empty("No rooms to show right now.");
      mount.replaceChildren.apply(mount, games.slice(0, COUNT).map(card));
    })
    .catch(function () {
      empty("Couldn't load rooms right now.");
    });
})();
