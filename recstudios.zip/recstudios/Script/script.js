let logoClickCount = 0;
let iconFlipped = false;
let iconsChanged = false;
let textChanged = false;
let rainbowEnabled = false;
let iconRotating = false;
let iconSizing = false;

const availableIcons = [
  "Icons/Create.png",
  "Icons/Cross-Platform.png",
  "Icons/Compete.png",
  "Icons/Cooperate.png",
  "Icons/default.png",
  "Icons/face.png",
  "Icons/Download/pc.png",
  "Icons/Download/android.png",
  "Icons/Download/quest.png",
  "Icons/RecTube.png",
  "Icons/Banner.png"
];

const randomTexts = [
  "Download",
  "Home",
  "RecTube",
  "Shop",
  "Rooms",
  "Events",
  "Inventions",
  "Credit",
  "Play",
  "Create",
  "Compete",
  "Cooperate",
  "Explore",
  "Build",
  "Launch",
  "Start",
  "Join",
  "Quest",
  "Discover",
  "Connect",
  "Game",
  "World",
  "Adventure",
  "Fun"
];

document.addEventListener("DOMContentLoaded", () => {
  loadState();
  applyAllEffects();

  document.querySelectorAll(".hero-logo").forEach(logo => {
    logo.addEventListener("click", handleLogoClick);
    logo.style.cursor = "pointer";
  });
});

function handleLogoClick(event) {
  event.preventDefault();
  event.stopPropagation();

  logoClickCount++;

  if (logoClickCount === 3) toggleIconFlip();
  if (logoClickCount === 6) changeIcons();
  if (logoClickCount === 9) changeText();
  if (logoClickCount === 12) toggleRainbow();
  if (logoClickCount === 15) toggleIconRotation();
  if (logoClickCount === 16) toggleIconSizing();
  if (logoClickCount === 17) resetAllEffects();

  saveState();
}

function getRandomIcon() {
  return availableIcons[Math.floor(Math.random() * availableIcons.length)];
}

function getRandomText() {
  return randomTexts[Math.floor(Math.random() * randomTexts.length)];
}

function toggleIconFlip() {
  iconFlipped = !iconFlipped;
  updateTransforms();
}

function changeIcons() {
  iconsChanged = !iconsChanged;

  document.querySelectorAll("img").forEach(icon => {
    if (iconsChanged) {
      if (!icon.dataset.originalSrc) {
        icon.dataset.originalSrc = icon.src;
      }

      icon.src = getRandomIcon();
    } else if (icon.dataset.originalSrc) {
      icon.src = icon.dataset.originalSrc;
      delete icon.dataset.originalSrc;
    }
  });

  changeBackgroundImages();
}

function changeBackgroundImages() {
  document.querySelectorAll("*").forEach(element => {
    const background = getComputedStyle(element).backgroundImage;

    if (!background || background === "none") {
      return;
    }

    if (iconsChanged) {
      if (!element.dataset.originalBg) {
        element.dataset.originalBg = background;
      }

      element.style.backgroundImage = `url("${getRandomIcon()}")`;
    } else if (element.dataset.originalBg) {
      element.style.backgroundImage = element.dataset.originalBg;
      delete element.dataset.originalBg;
    }
  });
}

function changeText() {
  textChanged = !textChanged;

  document.querySelectorAll("h1, h2, h3, p, a, button, li, span, div").forEach(element => {
    if (element.children.length === 0 && element.textContent.trim()) {
      if (textChanged) {
        if (!element.dataset.originalText) {
          element.dataset.originalText = element.textContent;
          element.textContent = getRandomText();
        }
      } else if (element.dataset.originalText) {
        element.textContent = element.dataset.originalText;
        delete element.dataset.originalText;
      }
    }
  });
}

function toggleRainbow() {
  rainbowEnabled = !rainbowEnabled;

  if (!document.getElementById("rainbow-style")) {
    const style = document.createElement("style");
    style.id = "rainbow-style";
    style.textContent = `
      @keyframes rainbow {
        0% { filter: hue-rotate(0deg) brightness(1.1); }
        25% { filter: hue-rotate(90deg) brightness(1.1); }
        50% { filter: hue-rotate(180deg) brightness(1.1); }
        75% { filter: hue-rotate(270deg) brightness(1.1); }
        100% { filter: hue-rotate(360deg) brightness(1.1); }
      }

      .rainbow-effect {
        animation: rainbow 3s linear infinite !important;
      }
    `;

    document.head.appendChild(style);
  }

  document.querySelectorAll("img").forEach(icon => {
    icon.classList.toggle("rainbow-effect", rainbowEnabled);
  });
}

function toggleIconRotation() {
  iconRotating = !iconRotating;
  updateAnimations();
}

function toggleIconSizing() {
  iconSizing = !iconSizing;
  updateAnimations();
}

function updateAnimations() {
  if (!document.getElementById("easter-egg-animation-style")) {
    const style = document.createElement("style");
    style.id = "easter-egg-animation-style";
    style.textContent = `
      @keyframes eggSpin {
        from { transform: rotate(0deg) scale(1); }
        to { transform: rotate(1080deg) scale(1.1); }
      }

      @keyframes eggSize {
        0%, 100% { transform: scale(.8); }
        50% { transform: scale(1.5); }
      }

      @keyframes eggSpinSize {
        from { transform: rotate(0deg) scale(.8); }
        to { transform: rotate(1080deg) scale(1.1); }
      }

      .icon-rotating {
        animation: eggSpin 5s linear infinite !important;
      }

      .icon-sizing {
        animation: eggSize 4s ease-in-out infinite !important;
      }

      .icon-rotation-and-sizing {
        animation: eggSpinSize 5s ease-in-out infinite !important;
      }
    `;

    document.head.appendChild(style);
  }

  document.querySelectorAll("img").forEach(icon => {
    icon.classList.remove("icon-rotating", "icon-sizing", "icon-rotation-and-sizing");

    if (iconRotating && iconSizing) {
      icon.classList.add("icon-rotation-and-sizing");
    } else if (iconRotating) {
      icon.classList.add("icon-rotating");
    } else if (iconSizing) {
      icon.classList.add("icon-sizing");
    }
  });

  if (!iconRotating && !iconSizing) {
    updateTransforms();
  }
}

function updateTransforms() {
  document.querySelectorAll("img").forEach(icon => {
    icon.style.transform = iconFlipped ? "scaleX(-1)" : "";
  });
}

function resetAllEffects() {
  logoClickCount = 0;
  iconFlipped = false;
  iconsChanged = false;
  textChanged = false;
  rainbowEnabled = false;
  iconRotating = false;
  iconSizing = false;

  document.querySelectorAll("img").forEach(icon => {
    if (icon.dataset.originalSrc) {
      icon.src = icon.dataset.originalSrc;
      delete icon.dataset.originalSrc;
    }

    icon.classList.remove(
      "rainbow-effect",
      "icon-rotating",
      "icon-sizing",
      "icon-rotation-and-sizing"
    );

    icon.style.transform = "";
    icon.style.filter = "";
  });

  document.querySelectorAll("*").forEach(element => {
    if (element.dataset.originalBg) {
      element.style.backgroundImage = element.dataset.originalBg;
      delete element.dataset.originalBg;
    }
  });

  document.querySelectorAll("h1, h2, h3, p, a, button, li, span, div").forEach(element => {
    if (element.dataset.originalText) {
      element.textContent = element.dataset.originalText;
      delete element.dataset.originalText;
    }
  });

  saveState();
}

function applyAllEffects() {
  if (iconsChanged) {
    document.querySelectorAll("img").forEach(icon => {
      if (!icon.dataset.originalSrc) {
        icon.dataset.originalSrc = icon.src;
        icon.src = getRandomIcon();
      }
    });

    changeBackgroundImages();
  }

  if (iconFlipped) {
    updateTransforms();
  }

  if (rainbowEnabled) {
    toggleRainbow();
  }

  if (iconRotating || iconSizing) {
    updateAnimations();
  }

  if (textChanged) {
    document.querySelectorAll("h1, h2, h3, p, a, button, li, span, div").forEach(element => {
      if (
        element.children.length === 0 &&
        element.textContent.trim() &&
        !element.dataset.originalText
      ) {
        element.dataset.originalText = element.textContent;
        element.textContent = getRandomText();
      }
    });
  }
}

function saveState() {
  localStorage.setItem("logoClickCount", logoClickCount);
  localStorage.setItem("iconFlipped", iconFlipped);
  localStorage.setItem("iconsChanged", iconsChanged);
  localStorage.setItem("textChanged", textChanged);
  localStorage.setItem("rainbowEnabled", rainbowEnabled);
  localStorage.setItem("iconRotating", iconRotating);
  localStorage.setItem("iconSizing", iconSizing);
}

function loadState() {
  logoClickCount = Number(localStorage.getItem("logoClickCount")) || 0;
  iconFlipped = localStorage.getItem("iconFlipped") === "true";
  iconsChanged = localStorage.getItem("iconsChanged") === "true";
  textChanged = localStorage.getItem("textChanged") === "true";
  rainbowEnabled = localStorage.getItem("rainbowEnabled") === "true";
  iconRotating = localStorage.getItem("iconRotating") === "true";
  iconSizing = localStorage.getItem("iconSizing") === "true";
}
