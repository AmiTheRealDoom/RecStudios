const DEFAULT_FAVICON_PATH = "Icons/RecQuiemFavicon.png";
const REVIUM_FAVICON_PATH = "Icons/ReviumFavicon.png";
const REVIUM_PAGES = ["reviumdownload", "photos"];

function isReviumPage() {
  const page = location.pathname
    .split("/")
    .pop()
    .replace(/\.html$/i, "")
    .toLowerCase();
  return REVIUM_PAGES.includes(page);
}

function applyFavicon() {
  let link = document.querySelector("link[rel='icon']");

  if (!link) {
    link = document.createElement("link");
    link.rel = "icon";
    document.head.appendChild(link);
  }

  link.type = "image/png";
  link.href = isReviumPage() ? REVIUM_FAVICON_PATH : DEFAULT_FAVICON_PATH;
}

applyFavicon();
