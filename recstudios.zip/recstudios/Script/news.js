(function () {
  var API_URL = "/api/news";
  var HOME_COUNT = 30;

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function formatDate(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  }

  function safeLink(url) {
    if (!url) return "";
    return /^(https?:\/\/|\/|[A-Za-z0-9_-]+\.html)/i.test(url) ? url : "";
  }

  var modal = null;
  var lastFocus = null;

  function buildModal() {
    modal = el("div", "news-modal");
    modal.hidden = true;
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "news-modal-title");

    var backdrop = el("div", "news-modal-backdrop");
    var card = el("article", "news-modal-card");

    var close = el("button", "news-modal-close", "\u00d7");
    close.type = "button";
    close.setAttribute("aria-label", "Close news");

    var img = el("img", "news-modal-img");
    img.alt = "";

    var inner = el("div", "news-modal-inner");
    var meta = el("div", "news-modal-meta");
    var title = el("h2", "news-modal-title");
    title.id = "news-modal-title";
    var body = el("div", "news-modal-body");
    var cta = el("a", "news-modal-cta", "Learn more \u2192");
    cta.hidden = true;

    inner.append(meta, title, body, cta);
    card.append(close, img, inner);
    modal.append(backdrop, card);
    document.body.appendChild(modal);

    backdrop.addEventListener("click", closeModal);
    close.addEventListener("click", closeModal);
    document.addEventListener("keydown", function (e) {
      if (!modal.hidden && e.key === "Escape") closeModal();
    });
  }

  function openModal(item) {
    if (!modal) buildModal();
    lastFocus = document.activeElement;

    var img = modal.querySelector(".news-modal-img");
    if (item.Image) {
      img.src = item.Image;
      img.hidden = false;
    } else {
      img.hidden = true;
    }

    var meta = modal.querySelector(".news-modal-meta");
    meta.replaceChildren(
      el("span", "news-tag", item.Tag || "News"),
      el("time", "news-date", formatDate(item.Created_at))
    );

    modal.querySelector(".news-modal-title").textContent = item.Title;

    var body = modal.querySelector(".news-modal-body");
    body.replaceChildren();
    var text = item.Body || item.Summary || "";
    text.split(/\n{2,}/).forEach(function (para) {
      if (para.trim()) body.appendChild(el("p", "", para.trim()));
    });

    var cta = modal.querySelector(".news-modal-cta");
    var link = safeLink(item.Link);
    if (link) {
      cta.href = link;
      if (/^https?:\/\//i.test(link)) {
        cta.target = "_blank";
        cta.rel = "noopener noreferrer";
      } else {
        cta.removeAttribute("target");
        cta.removeAttribute("rel");
      }
      cta.hidden = false;
    } else {
      cta.hidden = true;
    }

    modal.hidden = false;
    document.body.classList.add("news-modal-open");
    modal.querySelector(".news-modal-close").focus();
  }

  function closeModal() {
    if (!modal) return;
    modal.hidden = true;
    document.body.classList.remove("news-modal-open");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function buildCard(item, variant) {
    var card = el("button", "news-card news-card--" + variant);
    card.type = "button";

    var media = el("div", "news-card-media");
    if (item.Image) {
      var img = el("img");
      img.src = item.Image;
      img.alt = "";
      img.loading = "lazy";
      media.appendChild(img);
    } else {
      media.classList.add("news-card-media--empty");
    }
    if (item.Pinned) media.appendChild(el("span", "news-pin", "Pinned"));

    var body = el("div", "news-card-body");
    var meta = el("div", "news-card-meta");
    meta.append(el("span", "news-tag", item.Tag || "News"), el("time", "news-date", formatDate(item.Created_at)));

    body.append(meta, el("h3", "news-card-title", item.Title));
    if (item.Summary && variant !== "tile") {
      body.appendChild(el("p", "news-card-summary", item.Summary));
    }

    card.append(media, body);
    card.addEventListener("click", function () { openModal(item); });
    return card;
  }

  function fetchNews(limit) {
    return fetch(API_URL + "?limit=" + limit)
      .then(function (r) {
        if (!r.ok) throw new Error("bad response");
        return r.json();
      })
      .then(function (d) { return d.news || []; });
  }

  function initHome() {
    var mount = document.getElementById("home-news");
    if (!mount) return;

    fetchNews(HOME_COUNT)
      .then(function (items) {
        if (!items.length) return;

        var head = el("div", "home-news-head");
        var all = el("a", "home-news-all", "View all \u2192");
        all.href = "News.html";
        head.append(el("h2", "home-news-title", "Latest News"), all);

        var carousel = el("div", "home-photos-carousel");
        var prev = el("button", "home-photos-arrow home-photos-arrow--prev", "\u2039");
        prev.type = "button";
        prev.setAttribute("aria-label", "Previous news");
        var next = el("button", "home-photos-arrow home-photos-arrow--next", "\u203a");
        next.type = "button";
        next.setAttribute("aria-label", "Next news");
        var track = el("div", "home-photos-track");

        items.slice(0, HOME_COUNT).forEach(function (item) {
          track.appendChild(buildCard(item, "tile"));
        });

        function updateArrows() {
          prev.disabled = track.scrollLeft <= 1;
          next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
        }
        function slide(direction) {
          track.scrollBy({ left: direction * track.clientWidth * 0.9, behavior: "smooth" });
        }

        prev.addEventListener("click", function () { slide(-1); });
        next.addEventListener("click", function () { slide(1); });
        track.addEventListener("scroll", updateArrows, { passive: true });
        window.addEventListener("resize", updateArrows);

        carousel.append(prev, track, next);

        var inner = el("div", "home-news-inner");
        inner.append(head, carousel);
        mount.replaceChildren(inner);
        mount.hidden = false;
        updateArrows();
      })
      .catch(function () {});
  }

  function initList() {
    var list = document.getElementById("news-list");
    if (!list) return;

    fetchNews(100)
      .then(function (items) {
        list.replaceChildren();
        if (!items.length) {
          list.appendChild(el("p", "news-empty", "No news yet. Check back soon!"));
          return;
        }
        items.forEach(function (item) {
          list.appendChild(buildCard(item, "list"));
        });

        var id = new URLSearchParams(location.search).get("id");
        var match = id && items.find(function (i) { return i.NewsID === id; });
        if (match) openModal(match);
      })
      .catch(function () {
        list.replaceChildren(el("p", "news-empty", "Couldn't load the news right now."));
      });
  }

  function init() {
    initHome();
    initList();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
