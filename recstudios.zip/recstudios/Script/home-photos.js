(function () {
  var COUNT = 30;
  var mount = document.getElementById("home-photos");
  if (!mount) return;

  function el(tag, className, text) {
    var n = document.createElement(tag);
    if (className) n.className = className;
    if (text != null) n.textContent = text;
    return n;
  }

  function formatDate(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  }

  function buildCard(p) {
    var card = el("button", "news-card news-card--tile");
    card.type = "button";

    var media = el("div", "news-card-media");
    var img = el("img");
    img.src = p.url;
    img.alt = "Photo from Revium.Net";
    img.loading = "lazy";
    media.appendChild(img);

    var body = el("div", "news-card-body");
    var meta = el("div", "news-card-meta");
    meta.append(el("span", "news-tag", "Photo"), el("time", "news-date", formatDate(p.time)));
    body.append(meta, el("h3", "news-card-title", "Photo from the game"));

    card.append(media, body);
    card.addEventListener("click", function () {
      window.ReviumPhotoModal.open(p);
    });
    return card;
  }

  var track = null;
  var prev = null;
  var next = null;

  function updateArrows() {
    if (!track) return;
    prev.disabled = track.scrollLeft <= 1;
    next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
  }

  function slide(direction) {
    track.scrollBy({ left: direction * track.clientWidth * 0.9, behavior: "smooth" });
  }

  function buildShell() {
    var head = el("div", "home-news-head");
    var title = el("h2", "home-news-title home-photos-title notranslate");
    var logo = el("img", "home-photos-logo");
    logo.src = "Icons/ReviumWhiteLogo.png";
    logo.alt = "";
    title.append(logo, document.createTextNode("Revium.Net"));
    var all = el("a", "home-news-all", "View all \u2192");
    all.href = "Photos.html";
    head.append(title, all);

    var carousel = el("div", "home-photos-carousel");
    prev = el("button", "home-photos-arrow home-photos-arrow--prev", "\u2039");
    prev.type = "button";
    prev.setAttribute("aria-label", "Previous photos");
    next = el("button", "home-photos-arrow home-photos-arrow--next", "\u203a");
    next.type = "button";
    next.setAttribute("aria-label", "Next photos");
    track = el("div", "home-photos-track");

    prev.addEventListener("click", function () {
      slide(-1);
    });
    next.addEventListener("click", function () {
      slide(1);
    });
    track.addEventListener("scroll", updateArrows, { passive: true });
    window.addEventListener("resize", updateArrows);

    carousel.append(prev, track, next);

    var inner = el("div", "home-news-inner");
    inner.append(head, carousel);
    mount.replaceChildren(inner);
  }

  function render(photos) {
    var latest = photos
      .slice()
      .sort(function (a, b) {
        return new Date(b.time) - new Date(a.time);
      })
      .slice(0, COUNT);
    var key = latest
      .map(function (p) {
        return p.file;
      })
      .join("|");
    if (key === mount.dataset.key) return;
    mount.dataset.key = key;

    if (!track) buildShell();

    var position = track.scrollLeft;
    var frag = document.createDocumentFragment();
    latest.forEach(function (p) {
      frag.appendChild(buildCard(p));
    });
    track.replaceChildren(frag);
    track.scrollLeft = position;

    mount.hidden = false;
    updateArrows();
  }

  function load() {
    fetch("/api/photos")
      .then(function (r) {
        return r.json();
      })
      .then(function (photos) {
        if (Array.isArray(photos) && photos.length) render(photos);
      })
      .catch(function () {});
  }

  load();
  setInterval(function () {
    if (!document.hidden) load();
  }, 30000);
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) load();
  });
})();
