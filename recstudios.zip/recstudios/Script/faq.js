document.querySelectorAll(".faq-question").forEach(button => {
  button.addEventListener("click", () => {
    const item = button.closest(".faq-item");
    const isOpen = button.getAttribute("aria-expanded") === "true";
    const icon = button.querySelector(".faq-toggle-icon");

    button.setAttribute("aria-expanded", String(!isOpen));
    item.classList.toggle("open", !isOpen);

    if (icon) {
      icon.textContent = isOpen ? "+" : "\u2013";
    }
  });
});
