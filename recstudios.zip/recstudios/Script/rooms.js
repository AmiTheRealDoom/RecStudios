const GAMES_API_URL = "/api/rooms";
const DEFAULT_GAME_IMAGE = "Icons/default.png";
const ROOM_PAGE_URL = "Room.html";

const gamesGrid = document.getElementById("games-grid");
const gamesStatus = document.getElementById("games-status");
const gamesSearch = document.getElementById("games-search");

const roomStatus = document.getElementById("room-status");
const roomContent = document.getElementById("room-content");

let allGames = [];

function getGameValue(game, keys, fallback = "") {
  for (const key of keys) {
    if (
      game[key] !== undefined &&
      game[key] !== null &&
      String(game[key]).trim()
    ) {
      return String(game[key]).trim();
    }
  }

  return fallback;
}

function formatDate(value) {
  const date = new Date(value);

  if (!value || Number.isNaN(date.getTime())) {
    return "Unknown date";
  }

  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}

function getById(game) {
  return getGameValue(
    game,
    ["ByID", "by_id", "ById", "byId"],
    getGameValue(game, ["By"], "unknown")
  );
}

function getRoomId(game) {
  return getGameValue(
    game,
    ["RoomID", "room_id", "RoomId", "roomId"],
    getGameValue(game, ["RoomName", "room_name"], "unknown")
  );
}

function getThumbnail(game) {
  return getGameValue(
    game,
    ["Thumbnail", "thumbnail", "thumbnail_url", "thumbnailUrl", "RoomThumbnail", "room_thumbnail"],
    DEFAULT_GAME_IMAGE
  );
}

function getIcon(game) {
  return getGameValue(
    game,
    ["Icon", "icon", "icon_url", "iconUrl", "RoomIcon", "room_icon"],
    DEFAULT_GAME_IMAGE
  );
}

function setImage(image, source, alt) {
  image.src = source || DEFAULT_GAME_IMAGE;
  image.alt = alt;

  image.onerror = () => {
    if (!image.src.endsWith(DEFAULT_GAME_IMAGE)) {
      image.src = DEFAULT_GAME_IMAGE;
    }
  };
}

function createImage(source, alt, className) {
  const image = document.createElement("img");

  image.className = className;
  image.loading = "lazy";
  setImage(image, source, alt);

  return image;
}

function createRoomUrl(game) {
  const params = new URLSearchParams({
    ByID: getById(game),
    RoomID: getRoomId(game)
  });

  return `${ROOM_PAGE_URL}?${params.toString()}`;
}

function createGameCard(game) {
  const roomName = getGameValue(game, ["RoomName", "room_name"], "Unnamed Room");
  const creator = getGameValue(game, ["By", "by", "creator"], "Unknown creator");

  const card = document.createElement("article");
  card.className = "game-card";
  card.tabIndex = 0;
  card.setAttribute("role", "link");

  const media = document.createElement("div");
  media.className = "game-card-media";

  media.append(
    createImage(getThumbnail(game), `${roomName} thumbnail`, "game-thumbnail"),
    createImage(getIcon(game), `${roomName} icon`, "game-icon")
  );

  const content = document.createElement("div");
  content.className = "game-card-content";

  const title = document.createElement("h2");
  title.textContent = roomName;

  const details = document.createElement("div");
  details.className = "game-details";

  const creatorTag = document.createElement("span");
  creatorTag.className = "game-tag";
  creatorTag.textContent = `By ${creator}`;

  const dateTag = document.createElement("span");
  dateTag.className = "game-tag";
  dateTag.textContent = formatDate(game.Created_at);

  details.append(creatorTag, dateTag);
  content.append(title, details);
  card.append(media, content);

  const openRoom = () => {
    window.location.href = createRoomUrl(game);
  };

  card.addEventListener("click", openRoom);

  card.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openRoom();
    }
  });

  return card;
}

function getSearchText(game) {
  return [
    getGameValue(game, ["RoomName", "room_name"]),
    getGameValue(game, ["By", "by", "creator"]),
    getGameValue(game, ["RoomID", "room_id", "RoomId", "roomId"]),
    getGameValue(game, ["ByID", "by_id", "ById", "byId"]),
    getGameValue(game, ["Bio", "bio"])
  ]
    .join(" ")
    .toLowerCase();
}

function renderGames(games) {
  gamesGrid.replaceChildren();

  if (!games.length) {
    const emptyMessage = document.createElement("p");
    emptyMessage.className = "games-empty";
    emptyMessage.textContent = "No games found.";
    gamesGrid.append(emptyMessage);
    return;
  }

  games.forEach(game => {
    gamesGrid.append(createGameCard(game));
  });
}

function filterGames() {
  const searchTerm = (gamesSearch ? gamesSearch.value : "").trim().toLowerCase();

  const filteredGames = allGames.filter(game => {
    return getSearchText(game).includes(searchTerm);
  });

  gamesStatus.className = "games-status";
  gamesStatus.textContent = `${filteredGames.length} game${
    filteredGames.length === 1 ? "" : "s"
  } found.`;

  renderGames(filteredGames);
}

function showGamesError(message) {
  gamesStatus.className = "games-status error";
  gamesStatus.textContent = message;

  const retryButton = document.createElement("button");
  retryButton.className = "retry-button";
  retryButton.textContent = "Try Again";
  retryButton.addEventListener("click", loadPage);

  gamesStatus.append(document.createElement("br"), retryButton);
}

function getRoomParameters() {
  const params = new URLSearchParams(window.location.search);

  return {
    byId: params.get("ByID"),
    roomId: params.get("RoomID")
  };
}

function showRoomError(message) {
  document.title = "Recquiem - Room";
  roomStatus.className = "room-status error";
  roomStatus.textContent = message;
  roomContent.hidden = true;
}

function showRoom(game) {
  const roomName = getGameValue(game, ["RoomName", "room_name"], "Unnamed Room");
  const creator = getGameValue(game, ["By", "by", "creator"], "Unknown creator");
  const bio = getGameValue(game, ["Bio", "bio"], "No bio available.");

  document.title = `Recquiem - ${roomName}`;

  const thumbnail = document.getElementById("room-thumbnail");
  const icon = document.getElementById("room-icon");

  setImage(thumbnail, getThumbnail(game), `${roomName} thumbnail`);
  setImage(icon, getIcon(game), `${roomName} icon`);

  document.getElementById("room-name").textContent = roomName;
  document.getElementById("room-creator").textContent = `Created by ${creator}`;
  document.getElementById("room-date").textContent = formatDate(game.Created_at);
  document.getElementById("room-bio").textContent = bio;

  roomStatus.hidden = true;
  roomContent.hidden = false;

  if (window.initRoomReactions) {
    window.initRoomReactions(getRoomId(game));
  }
}

async function loadRoom(games) {
  const { byId, roomId } = getRoomParameters();

  if (!byId || !roomId) {
    showRoomError("This room URL is missing its room information.");
    return;
  }

  const room = games.find(game => {
    return getById(game) === byId && getRoomId(game) === roomId;
  });

  if (!room) {
    showRoomError("Room not found.");
    return;
  }

  showRoom(room);
}

async function loadPage() {
  const isRoomPage = Boolean(roomStatus && roomContent);

  if (!isRoomPage) {
    gamesStatus.replaceChildren();
    gamesStatus.className = "games-status";
    gamesStatus.textContent = "Loading games...";
  }

  try {
    const response = await fetch(GAMES_API_URL);

    if (!response.ok) {
      throw new Error(`Database request failed with status ${response.status}`);
    }

    const result = await response.json();
    const games = Array.isArray(result) ? result : result.rooms || result.games;

    if (!Array.isArray(games)) {
      throw new Error("Invalid games response.");
    }

    if (isRoomPage) {
      await loadRoom(games);
    } else {
      allGames = games;
      filterGames();
    }
  } catch (error) {
    console.error("Failed to load page:", error);

    if (isRoomPage) {
      showRoomError("Unable to load this room.");
    } else {
      showGamesError("Unable to load games from the Recquiem database.");
    }
  }
}

if (gamesSearch) {
  gamesSearch.addEventListener("input", filterGames);
}

loadPage();
