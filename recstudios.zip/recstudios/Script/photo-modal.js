(function () {
  var modal = null;
  var lastFocus = null;

  function el(tag, className, text) {
    var n = document.createElement(tag);
    if (className) n.className = className;
    if (text != null) n.textContent = text;
    return n;
  }

  function formatDate(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  }

  function close() {
    if (!modal) return;
    modal.hidden = true;
    document.body.classList.remove("news-modal-open");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function build() {
    modal = el("div", "news-modal");
    modal.hidden = true;
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");

    var backdrop = el("div", "news-modal-backdrop");
    var card = el("article", "news-modal-card photo-modal-card");
    var closeBtn = el("button", "news-modal-close", "\u00d7");
    closeBtn.type = "button";
    closeBtn.setAttribute("aria-label", "Close photo");
    var img = el("img", "news-modal-img");
    img.alt = "";
    var inner = el("div", "news-modal-inner");
    inner.append(el("div", "news-modal-meta"), el("h2", "news-modal-title", "Photo from the game"));
    card.append(closeBtn, img, inner);
    modal.append(backdrop, card);
    document.body.appendChild(modal);

    backdrop.addEventListener("click", close);
    closeBtn.addEventListener("click", close);
    document.addEventListener("keydown", function (e) {
      if (!modal.hidden && e.key === "Escape") close();
    });
  }

  window.ReviumPhotoModal = {
    open: function (p) {
      if (!modal) build();
      lastFocus = document.activeElement;
      modal.querySelector(".news-modal-img").src = p.url;
      modal
        .querySelector(".news-modal-meta")
        .replaceChildren(
          el("span", "news-tag", "Photo"),
          el("time", "news-date", formatDate(p.time))
        );
      modal.hidden = false;
      document.body.classList.add("news-modal-open");
      modal.querySelector(".news-modal-close").focus();
    }
  };
})();
