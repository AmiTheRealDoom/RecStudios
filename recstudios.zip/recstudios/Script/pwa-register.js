if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}

let deferredInstallPrompt = null;

const ua = navigator.userAgent || "";

function isIosDevice() {
  return (
    /iphone|ipad|ipod/i.test(ua) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
  );
}

function isStandaloneDisplay() {
  const modes = ["standalone", "fullscreen", "minimal-ui", "window-controls-overlay"];
  return (
    window.navigator.standalone === true ||
    modes.some(mode => window.matchMedia("(display-mode: " + mode + ")").matches)
  );
}

function getManualTip() {
  if (isIosDevice()) {
    return "Tap the Share icon in your browser, then \u201cAdd to Home Screen\u201d to install RecQuiem.";
  }
  const isSafari = /safari/i.test(ua) && !/chrome|chromium|crios|fxios|edg|opr|android/i.test(ua);
  if (isSafari) {
    return "In the menu bar choose File \u2192 Add to Dock to install RecQuiem.";
  }
  if (/firefox/i.test(ua) && /android/i.test(ua)) {
    return "Open the browser menu (\u22ee) and tap Install to add RecQuiem to your home screen.";
  }
  if (/firefox/i.test(ua)) {
    return "Firefox can\u2019t install apps on desktop. Open RecQuiem in Chrome or Edge to install it.";
  }
  if (/android/i.test(ua)) {
    return "Open the browser menu (\u22ee) and tap Install app or Add to Home screen.";
  }
  return "Open your browser menu and choose Install RecQuiem, or click the install icon in the address bar.";
}

const INSTALLED_KEY = "rq-app-installed";
const DAY_MS = 24 * 60 * 60 * 1000;

function readInstalledStamp() {
  try {
    const raw = localStorage.getItem(INSTALLED_KEY);
    if (!raw) return 0;
    if (raw === "1") return 1;
    const stamp = parseInt(raw, 10);
    return stamp > 0 ? stamp : 0;
  } catch (error) {
    return 0;
  }
}

function readInstalledFlag() {
  return readInstalledStamp() > 0;
}

function writeInstalledFlag() {
  try {
    localStorage.setItem(INSTALLED_KEY, String(Date.now()));
  } catch (error) {}
}

function clearInstalledFlag() {
  try {
    localStorage.removeItem(INSTALLED_KEY);
  } catch (error) {}
}

let installed = isStandaloneDisplay() || readInstalledFlag();

if (isStandaloneDisplay()) writeInstalledFlag();

if (typeof navigator.getInstalledRelatedApps === "function") {
  navigator
    .getInstalledRelatedApps()
    .then(apps => {
      if (apps && apps.length) {
        installed = true;
        writeInstalledFlag();
        updateInstallButtons();
      }
    })
    .catch(() => {});
}

function recheckAfterPrompt() {
  if (isStandaloneDisplay()) {
    installed = true;
    writeInstalledFlag();
    updateInstallButtons();
    return;
  }

  const stamp = readInstalledStamp();
  if (!stamp) {
    installed = false;
    updateInstallButtons();
    return;
  }

  const age = stamp === 1 ? Infinity : Date.now() - stamp;

  if (typeof navigator.getInstalledRelatedApps === "function") {
    navigator
      .getInstalledRelatedApps()
      .then(apps => {
        if (apps && apps.length) {
          installed = true;
          writeInstalledFlag();
        } else if (age > DAY_MS) {
          installed = false;
          clearInstalledFlag();
        }
        updateInstallButtons();
      })
      .catch(() => {});
    return;
  }

  if (age > 30 * DAY_MS) {
    installed = false;
    clearInstalledFlag();
  }
  updateInstallButtons();
}

const INSTALL_CSS = `
.rq-install {
  position: fixed;
  right: max(16px, env(safe-area-inset-right));
  bottom: max(16px, env(safe-area-inset-bottom));
  z-index: 140;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
  font-family: var(--font-body, system-ui, sans-serif);
}
.rq-install[hidden] { display: none !important; }
@media (max-width: 1024px), (hover: none) and (pointer: coarse) {
  .rq-install { bottom: calc(var(--bottombar-height, 64px) + 14px + env(safe-area-inset-bottom)); }
}
@media (orientation: landscape) and (max-height: 520px) {
  .rq-install { bottom: calc(var(--bottombar-height, 46px) + 8px + env(safe-area-inset-bottom)); }
  .rq-install-btn { padding: 10px 16px; font-size: 14px; }
}
.rq-install-btn {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 14px 25px;
  border: 0;
  border-radius: var(--radius-sm, 10px);
  background: var(--rr-blue, #1e40af);
  color: #fff;
  font: inherit;
  font-size: 16px;
  font-weight: 800;
  cursor: pointer;
  transition: background 0.15s, transform 0.15s;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
}
.rq-install-btn svg { width: 20px; height: 20px; fill: currentColor; flex: none; }
.rq-install-btn:hover { background: var(--rr-blue-hover, #17338a); transform: translateY(-1px); }
.rq-install-btn:focus-visible { outline: 3px solid #fff; outline-offset: 2px; }
.rq-install-tip {
  max-width: min(320px, calc(100vw - 32px));
  padding: 12px 14px;
  border-radius: var(--radius-sm, 10px);
  background: #fff;
  color: #1b1b1d;
  font-size: 14px;
  line-height: 1.4;
  font-weight: 800;
}
.rq-install-tip[hidden] { display: none !important; }
`;

const ICON_SVG =
  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 20h14v-2H5v2Zm7-4 6-6-1.4-1.4L13 12.2V3h-2v9.2L7.4 8.6 6 10l6 6Z"/></svg>';

let installRoot = null;

function buildInstallUi() {
  if (installRoot || !document.body) return;

  const style = document.createElement("style");
  style.textContent = INSTALL_CSS;
  document.head.appendChild(style);

  installRoot = document.createElement("div");
  installRoot.className = "rq-install";
  installRoot.hidden = true;
  installRoot.innerHTML =
    '<div id="ios-install-tip" class="rq-install-tip" role="status" hidden>' +
    'Tap the Share icon in your browser, then \u201cAdd to Home Screen\u201d to install RecQuiem.</div>' +
    '<button id="pwa-install-btn" class="rq-install-btn" type="button" aria-label="Install the RecQuiem app">' +
    '<span>Install app</span>' + ICON_SVG + '</button>';
  document.body.appendChild(installRoot);
}

function isHomePage() {
  const path = location.pathname.replace(/\/+$/, "").toLowerCase();
  return path === "" || path === "/home" || path === "/home.html" || path === "/index.html";
}

function updateInstallButtons() {
  if (!isHomePage()) return;
  buildInstallUi();
  if (installRoot) installRoot.hidden = installed;
}

function hideTip() {
  document.querySelectorAll("#ios-install-tip").forEach(tip => tip.setAttribute("hidden", ""));
}

function toggleTip() {
  document.querySelectorAll("#ios-install-tip").forEach(tip => {
    if (tip.hasAttribute("hidden")) {
      tip.textContent = getManualTip();
      tip.removeAttribute("hidden");
    } else {
      tip.setAttribute("hidden", "");
    }
  });
}

function runInstall() {
  if (!deferredInstallPrompt) {
    toggleTip();
    return;
  }
  const promptEvent = deferredInstallPrompt;
  deferredInstallPrompt = null;
  promptEvent.prompt();
  promptEvent.userChoice.then(choice => {
    if (choice && choice.outcome === "accepted") {
      installed = true;
      writeInstalledFlag();
      updateInstallButtons();
    }
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", updateInstallButtons);
} else {
  updateInstallButtons();
}

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  recheckAfterPrompt();
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  installed = true;
  writeInstalledFlag();
  updateInstallButtons();
});

document.addEventListener("click", event => {
  if (event.target.closest("#pwa-install-btn")) {
    runInstall();
    return;
  }

  if (!event.target.closest("#ios-install-tip")) {
    hideTip();
  }
});

(function () {
  "use strict";

  if (window.RQInstantNav) {
    return;
  }

  var SKIP_PAGES = ["admin", "download", "reviumdownload", "topbar"];
  var warmed = {};
  var hoverTimer = null;

  function pageName(url) {
    return String(url.pathname || "")
      .split("/")
      .pop()
      .toLowerCase()
      .replace(/\.html$/, "");
  }

  function eligible(link) {
    if (!link || !link.href || link.hasAttribute("download")) {
      return null;
    }

    var target = (link.getAttribute("target") || "").toLowerCase();

    if (target && target !== "_self") {
      return null;
    }

    var url;

    try {
      url = new URL(link.href, window.location.href);
    } catch (error) {
      return null;
    }

    if (url.origin !== window.location.origin || url.pathname.indexOf("/api/") === 0) {
      return null;
    }

    var name = pageName(url);

    if (!name || SKIP_PAGES.indexOf(name) !== -1) {
      return null;
    }

    if (url.pathname === window.location.pathname && url.search === window.location.search) {
      return null;
    }

    url.hash = "";
    return url;
  }

  function warm(link) {
    var url = eligible(link);

    if (!url) {
      return;
    }

    var key = url.pathname.replace(/\.html$/i, "");

    if (warmed[key]) {
      return;
    }

    warmed[key] = true;

    try {
      fetch(key, { credentials: "same-origin", priority: "low" }).catch(function () {
        warmed[key] = false;
      });
    } catch (error) {
      warmed[key] = false;
    }
  }

  function linkFrom(event) {
    return event.target && event.target.closest ? event.target.closest("a[href]") : null;
  }

  document.addEventListener(
    "touchstart",
    function (event) {
      warm(linkFrom(event));
    },
    { passive: true, capture: true }
  );

  document.addEventListener(
    "pointerdown",
    function (event) {
      warm(linkFrom(event));
    },
    { passive: true, capture: true }
  );

  document.addEventListener(
    "mouseover",
    function (event) {
      var link = linkFrom(event);

      clearTimeout(hoverTimer);

      if (link) {
        hoverTimer = setTimeout(function () {
          warm(link);
        }, 65);
      }
    },
    { passive: true, capture: true }
  );

  document.addEventListener(
    "focusin",
    function (event) {
      warm(linkFrom(event));
    },
    { passive: true }
  );

  window.RQInstantNav = { warm: warm };
})();
