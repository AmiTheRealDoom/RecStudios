(function () {
  var ENABLED = true;
  var TITLE = "Maintenance Notice";
  var MESSAGE =
    "Servers on MeowNet Edition are down while we transition to Alpha 2.";
  var LINK_TEXT = "status page";
  var LINK_HREF = "Status.html";
  var VERSION = "host-maintenance-2";

  if (!ENABLED || document.getElementById("maint-banner")) return;
  try {
    if (sessionStorage.getItem("rr-maint-dismissed") === VERSION) return;
  } catch (e) {}

  var css = document.createElement("style");
  css.textContent =
    "#maint-banner{position:fixed;top:0;left:0;right:0;z-index:900;display:flex;align-items:center;gap:16px;" +
    "padding:12px 24px;background:#8a6a2f;color:var(--text-light);font:14px/1.5 var(--font-body)}" +
    "#maint-banner,#maint-banner *{font-weight: 800}" +
    "#maint-banner .maint-icon{flex:none;height:52px;width:auto;display:block;border-radius:0}" +
    "#maint-banner .maint-text{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;text-align:center}" +
    "#maint-banner .maint-text span{color:var(--text-light);font-family:var(--font-body)}" +
    "#maint-banner .maint-title{color:var(--text-light);font-family:var(--font-display);font-size:16px;font-weight: 800;line-height:1.2}" +
    "#maint-banner a{color:var(--text-light);font-family:var(--font-body);text-decoration:underline}" +
    "#maint-banner button{flex:none;border:0;border-radius:var(--radius-sm);background:transparent;color:var(--text-light);" +
    "padding:8px 14px;font-family:var(--font-display);font-size:13px;cursor:pointer;transition:background-color .15s ease}" +
    "#maint-banner button:hover{background:rgba(0,0,0,.2)}" +
    "body.has-announcement #site-topbar.topnav{top:var(--announcement-h,0px)}" +
    "@media(max-width:1024px),(hover:none) and (pointer:coarse){#maint-banner{position:relative;top:auto;left:auto;right:auto;z-index:1;" +
    "flex:none;width:100%;box-sizing:border-box;" +
    "padding:12px max(16px,env(safe-area-inset-right)) 12px max(16px,env(safe-area-inset-left))}" +
    "body.has-announcement #site-topbar.topnav{top:0}}" +
    "@media(max-width:480px){#maint-banner{gap:10px;padding:10px 12px;font-size:13px}#maint-banner .maint-icon{height:36px}" +
    "#maint-banner button{padding:8px 10px}}" +
    "@media(orientation:landscape) and (max-height:520px){#maint-banner{padding-top:6px;padding-bottom:6px}" +
    "#maint-banner .maint-icon{height:32px}#maint-banner .maint-text{flex-direction:row;flex-wrap:wrap;justify-content:center;gap:2px 10px}}";
  document.head.appendChild(css);

  var bar = document.createElement("div");
  bar.id = "maint-banner";
  bar.setAttribute("role", "status");

  var text = document.createElement("div");
  text.className = "maint-text";

  var icon = document.createElement("img");
  icon.className = "maint-icon";
  icon.src = "Icons/MaintenanceCrew.png";
  icon.alt = "";

  var title = document.createElement("strong");
  title.className = "maint-title";
  title.textContent = TITLE;

  var msg = document.createElement("span");
  msg.textContent = MESSAGE;
  if (!/status/i.test(location.pathname)) {
    var a = document.createElement("a");
    a.href = LINK_HREF;
    a.textContent = LINK_TEXT;
    msg.append(" For more info, check the ", a, ".");
  }

  text.append(title, msg);

  var btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Dismiss";

  var observer = null;

  var mobileMq = window.matchMedia
    ? window.matchMedia("(max-width:1024px), (hover:none) and (pointer:coarse)")
    : { matches: false };

  function place() {
    var main = document.querySelector("main");
    if (mobileMq.matches && main) {
      if (bar.parentNode !== main || main.firstChild !== bar) main.insertBefore(bar, main.firstChild);
    } else if (bar.parentNode !== document.body) {
      document.body.appendChild(bar);
    }
  }

  function setOffset() {
    place();
    var h = mobileMq.matches ? 0 : bar.getBoundingClientRect().height;
    document.documentElement.style.setProperty("--announcement-h", h + "px");
  }

  btn.addEventListener("click", function () {
    bar.remove();
    document.body.classList.remove("has-announcement");
    document.documentElement.style.removeProperty("--announcement-h");
    window.removeEventListener("resize", setOffset);
    window.removeEventListener("orientationchange", setOffset);
    if (mobileMq.removeEventListener) mobileMq.removeEventListener("change", setOffset);
    if (observer) observer.disconnect();
    try {
      sessionStorage.setItem("rr-maint-dismissed", VERSION);
    } catch (e) {}
  });

  bar.append(icon, text, btn);
  document.body.appendChild(bar);
  document.body.classList.add("has-announcement");
  setOffset();
  if (mobileMq.addEventListener) mobileMq.addEventListener("change", setOffset);
  window.addEventListener("resize", setOffset);
  window.addEventListener("orientationchange", setOffset);
  window.addEventListener("load", setOffset);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(setOffset);
  if (window.ResizeObserver) {
    observer = new ResizeObserver(setOffset);
    observer.observe(bar);
  }
})();
