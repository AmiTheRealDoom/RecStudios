(function () {
  const AUTH_STORAGE_KEY = "RecquiemUserSession";
  const LOGIN_API_URL = "/api/auth-login";
  const REGISTER_API_URL = "/api/auth-register";
  const DELETE_API_URL = "/api/auth-delete";
  const AUTH_EVENT = "recquiem:auth-changed";

  function getSession() {
    try {
      const session = JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY) || "null");
      return session && session.token ? session : null;
    } catch {
      return null;
    }
  }

  function saveSession(session) {
    try {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session));
    } catch {}
    document.dispatchEvent(new CustomEvent(AUTH_EVENT));
  }

  function clearSession() {
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch {}
    document.dispatchEvent(new CustomEvent(AUTH_EVENT));
  }

  window.recquiemAuth = { getSession, clearSession, logout: clearSession };

  function byId(id) {
    return document.getElementById(id);
  }

  function updateAuthStatus() {
    const openBtn = byId("auth-open-btn");
    const loggedIn = byId("auth-logged-in");
    if (!openBtn && !loggedIn) return;

    const session = getSession();
    if (openBtn) openBtn.hidden = Boolean(session);
    if (loggedIn) loggedIn.hidden = !session;
  }

  function wireAccountButtons() {
    const logoutBtn = byId("auth-logout-btn");
    const deleteBtn = byId("auth-delete-btn");

    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => {
        clearSession();
      });
    }

    if (deleteBtn) {
      deleteBtn.addEventListener("click", async () => {
        const session = getSession();
        if (!session) return;

        if (!window.confirm("Delete your account permanently? This cannot be undone.")) {
          return;
        }

        deleteBtn.disabled = true;

        try {
          const response = await fetch(DELETE_API_URL, {
            method: "DELETE",
            headers: { Authorization: `Bearer ${session.token}` }
          });

          if (!response.ok) {
            const data = await response.json().catch(() => ({}));
            window.alert(data.error || "Unable to delete your account.");
            return;
          }

          clearSession();
        } catch (error) {
          console.error("Account deletion failed:", error);
          window.alert("Network error. Unable to connect to server.");
        } finally {
          deleteBtn.disabled = false;
        }
      });
    }
  }

  function wireAuthForm() {
    const form = byId("auth-form");
    if (!form) return;

    const emailInput = byId("auth-email");
    const passwordInput = byId("auth-password");
    const submitBtn = byId("auth-submit-btn");
    const errorEl = byId("auth-error");
    const title = byId("auth-modal-title");
    const subtitle = byId("auth-modal-subtitle");
    const toggleText = byId("auth-toggle-text");
    const toggleBtn = byId("auth-toggle-btn");

    let mode = "login";

    function setMessage(text, isError = true) {
      if (!errorEl) return;
      errorEl.textContent = text;
      errorEl.hidden = !text;
      errorEl.className = isError ? "auth-error" : "auth-error auth-error--success";
    }

    function getTurnstileToken() {
      if (typeof turnstile !== "undefined") {
        try {
          return turnstile.getResponse() || "";
        } catch {}
      }

      const fallback = form.querySelector('[name="cf-turnstile-response"]');
      return fallback ? fallback.value : "";
    }

    function resetTurnstile() {
      if (typeof turnstile !== "undefined") {
        try {
          turnstile.reset();
        } catch {}
      }
    }

    function applyMode() {
      const isLogin = mode === "login";

      if (title) title.textContent = isLogin ? "Log in to RecQuiem" : "Sign up for RecQuiem";
      if (subtitle) {
        subtitle.textContent = isLogin
          ? "Log in to your RecQuiem account to join the community, share moments, and manage your profile."
          : "Create a RecQuiem account to join the community, share moments, and manage your profile.";
      }
      if (submitBtn) submitBtn.textContent = isLogin ? "Log In" : "Sign Up";
      if (toggleText) toggleText.textContent = isLogin ? "Don't have an account?" : "Already have an account?";
      if (toggleBtn) toggleBtn.textContent = isLogin ? "Sign Up" : "Log In";
      if (passwordInput) {
        passwordInput.autocomplete = isLogin ? "current-password" : "new-password";
      }

      setMessage("");
    }

    async function handleSubmit(event) {
      event.preventDefault();

      const email = emailInput.value.trim();
      const password = passwordInput.value;
      const turnstileToken = getTurnstileToken();

      if (!email || !password) {
        setMessage("Please enter your email and password.");
        return;
      }

      if (!turnstileToken) {
        setMessage("Please complete the captcha.");
        return;
      }

      setMessage(mode === "login" ? "Logging in..." : "Creating your account...", false);
      submitBtn.disabled = true;

      try {
        const response = await fetch(mode === "login" ? LOGIN_API_URL : REGISTER_API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password, turnstileToken })
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
          setMessage(result.error || "Unable to continue.");
          return;
        }

        setMessage(mode === "login" ? "Logged in successfully." : "Account created.", false);
        saveSession({ token: result.token, user: result.user });
      } catch (error) {
        console.error("Auth request failed:", error);
        setMessage("Network error. Unable to connect to server.");
      } finally {
        submitBtn.disabled = false;
        resetTurnstile();
      }
    }

    form.addEventListener("submit", handleSubmit);

    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => {
        mode = mode === "login" ? "register" : "login";
        applyMode();
        resetTurnstile();
      });
    }

    applyMode();
  }

  document.addEventListener(AUTH_EVENT, updateAuthStatus);
  window.addEventListener("storage", event => {
    if (event.key === AUTH_STORAGE_KEY) updateAuthStatus();
  });

  function init() {
    updateAuthStatus();
    wireAccountButtons();
    wireAuthForm();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
